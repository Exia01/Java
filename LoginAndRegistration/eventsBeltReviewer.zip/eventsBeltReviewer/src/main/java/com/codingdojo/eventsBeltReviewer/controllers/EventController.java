package com.codingdojo.eventsBeltReviewer.controllers;


@Controller
public class EventController {


    
}