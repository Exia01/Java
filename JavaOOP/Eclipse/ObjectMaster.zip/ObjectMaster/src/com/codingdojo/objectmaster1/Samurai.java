package com.codingdojo.objectmaster1;

public class Samurai {

	public Samurai() {
		// TODO Auto-generated constructor stub
	}

}
