package com.codingdojo.objectmaster1;

public class Ninja {

	public Ninja() {
		// TODO Auto-generated constructor stub
	}

}

