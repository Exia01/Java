package com.codingdojo.objectmaster1;

public class Wizard {

	public Wizard() {
		// TODO Auto-generated constructor stub
	}

}
