package com.codingdojo.dojoOverflow.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("") // May or may not be needed, it just appends it automatically, still needs to be  typed....
public class TagController { //make sure this is not similar in this route.................. please.....I did the mistake of it earlier. Hence why its empty

}
