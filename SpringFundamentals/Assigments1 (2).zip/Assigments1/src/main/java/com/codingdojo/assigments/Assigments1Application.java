package com.codingdojo.assigments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assigments1Application {

	public static void main(String[] args) {
		SpringApplication.run(Assigments1Application.class, args);
	}
}
