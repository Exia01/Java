package com.codingdojo.assigments;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable; //path variables are for {{parameter}}
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam; //queries are being implemented 
//import org.springframework.web.bind.annotation.RestController; // not needed since we are doing templates.

@Controller
public class HomeController {
	@RequestMapping("")
	public String index() {
		return "index.jsp";
	}

	@RequestMapping("/date")
	public String hello(Model model) {
		Date date = new java.util.Date(); // this creates a new instance

		SimpleDateFormat newformat = new SimpleDateFormat("MMMM d, yyyy"); // built in function

		String newdate = newformat.format(date); // creating a string format of it.

		model.addAttribute("date", newdate); // adding the new date string to the model.
		return "date.jsp";
	}
	
	 @RequestMapping("/time") 
	    public String world(Model model){
	    	Date date = new java.util.Date(); // same as date this is creating an instance. 
	    	
	    	SimpleDateFormat newformat = new SimpleDateFormat("h:mm aa"); // formatting
	    	
	    	String newdate = newformat.format(date);  //creating the variable 
	        model.addAttribute("date", newdate);
	      return "time.jsp";
	    }

	@RequestMapping("/hello/") // index.jsp //?name=testing this is the key to doing it.
	public String hello(Model model,
			@RequestParam(value = "name", required = false, defaultValue = "World") String name) {
		model.addAttribute("name", name);
		return "Hello.jsp";
	}

	@RequestMapping("/goodbye/{name}") // this passes the variable parameter onto the doc.
	public String bye(@PathVariable("name") String name, Model model) {
		model.addAttribute("name", name);
		return "goodBye.jsp";
	}
}
